package com.example.watchtest;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {
    private static final String PREFS = "app_settings";
    private SharedPreferences prefs;
    private String editingUser = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        showHome();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView title(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(24);
        view.setTextColor(0xFFFFFFFF);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(12), dp(18), dp(12), dp(18));
        return view;
    }

    private TextView section(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(18);
        view.setTextColor(0xFF80CBC4);
        view.setPadding(0, dp(16), 0, dp(8));
        return view;
    }

    private TextView label(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(0xFFE0E0E0);
        view.setTextSize(15);
        view.setPadding(0, dp(8), 0, dp(2));
        return view;
    }

    private EditText field(String hint, String value) {
        EditText edit = new EditText(this);
        edit.setHint(hint);
        edit.setText(value == null ? "" : value);
        edit.setTextColor(0xFFFFFFFF);
        edit.setHintTextColor(0xFF9E9E9E);
        edit.setPadding(dp(12), dp(8), dp(12), dp(8));
        return edit;
    }

    private Button button(String text, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(text);
        button.setOnClickListener(listener);
        return button;
    }

    private LinearLayout base(String heading) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(10), dp(18), dp(18));
        root.setBackgroundColor(0xFF101820);
        root.addView(title(heading));
        return root;
    }

    private ScrollView scroll(LinearLayout content) {
        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);
        return scroll;
    }

    private void showHome() {
        LinearLayout page = base("TikTok Tools – Android");
        page.addView(section("Prototype Android"));
        TextView info = label("Les réglages sont enregistrés directement dans l’application. Aucun fichier apk.txt, config.json ou time.txt n’est nécessaire.");
        page.addView(info);
        page.addView(button("Comptes", v -> showAccounts()));
        page.addView(button("Paramètres généraux", v -> showSettings()));
        page.addView(button("Délais et répétitions", v -> showDelays()));
        page.addView(button("Positions et zones", v -> showPositions()));
        page.addView(button("Ouvrir un lien", v -> showOpenLink()));
        page.addView(button("À propos et limites", v -> showAbout()));
        setContentView(scroll(page));
    }

    private void addBackButton(LinearLayout page) {
        page.addView(button("← Retour à l’accueil", v -> showHome()));
    }

    private void showSettings() {
        LinearLayout page = base("Paramètres généraux");
        page.addView(section("Services et identifiants d’action"));
        EditText server = field("URL du serveur", prefs.getString("server_url", "http://localhost:8000"));
        EditText search = field("Lien de recherche ou vidéo", prefs.getString("search_url", ""));
        EditText bot = field("Nom du bot Telegram", prefs.getString("bot_name", ""));
        EditText likeId = field("Resource ID Like", prefs.getString("like_resource_id", "ejl"));
        EditText commentId = field("Resource ID Commentaire", prefs.getString("comment_resource_id", "eec"));
        page.addView(server);
        page.addView(search);
        page.addView(bot);
        page.addView(likeId);
        page.addView(commentId);
        page.addView(button("Enregistrer les paramètres", v -> {
            prefs.edit().putString("server_url", server.getText().toString().trim())
                    .putString("search_url", search.getText().toString().trim())
                    .putString("bot_name", bot.getText().toString().trim())
                    .putString("like_resource_id", likeId.getText().toString().trim())
                    .putString("comment_resource_id", commentId.getText().toString().trim())
                    .apply();
            toast("Paramètres enregistrés dans l’application");
        }));
        addBackButton(page);
        setContentView(scroll(page));
    }

    private void showDelays() {
        LinearLayout page = base("Délais et répétitions");
        page.addView(section("Valeurs en secondes"));
        EditText response = numberField("Délai de réponse", prefs.getInt("response_delay", 2));
        EditText task = numberField("Délai entre les tâches", prefs.getInt("task_delay", 0));
        EditText follow = numberField("Délai après Follow", prefs.getInt("follow_delay", 5));
        EditText repeat = numberField("Répétitions par compte", prefs.getInt("repeat_count", 1));
        EditText typing = field("Vitesse de saisie, en secondes", prefs.getString("typing_speed", "0.035"));
        typing.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        page.addView(response);
        page.addView(task);
        page.addView(follow);
        page.addView(repeat);
        page.addView(typing);
        page.addView(button("Enregistrer les délais", v -> {
            prefs.edit().putInt("response_delay", positive(response, 2))
                    .putInt("task_delay", positive(task, 0))
                    .putInt("follow_delay", positive(follow, 5))
                    .putInt("repeat_count", positive(repeat, 1))
                    .putString("typing_speed", typing.getText().toString().trim()).apply();
            toast("Délais enregistrés");
        }));
        addBackButton(page);
        setContentView(scroll(page));
    }

    private EditText numberField(String hint, int value) {
        EditText edit = field(hint, String.valueOf(value));
        edit.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return edit;
    }

    private int positive(EditText edit, int fallback) {
        try {
            int value = Integer.parseInt(edit.getText().toString().trim());
            return value >= 0 ? value : fallback;
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private void showPositions() {
        LinearLayout page = base("Positions et zones");
        page.addView(section("Coordonnées tactiles et zones"));
        EditText followX = numberField("Follow – X", prefs.getInt("follow_x", 0));
        EditText followY = numberField("Follow – Y", prefs.getInt("follow_y", 0));
        EditText commentX = numberField("Publier commentaire – X", prefs.getInt("comment_x", 949));
        EditText commentY = numberField("Publier commentaire – Y", prefs.getInt("comment_y", 2179));
        EditText okX = numberField("OK – X", prefs.getInt("ok_x", 0));
        EditText okY = numberField("OK – Y", prefs.getInt("ok_y", 0));
        EditText searchX = numberField("Recherche – X", prefs.getInt("search_x", 674));
        EditText searchY = numberField("Recherche – Y", prefs.getInt("search_y", 100));
        EditText enterX = numberField("Entrée – X", prefs.getInt("enter_x", 540));
        EditText enterY = numberField("Entrée – Y", prefs.getInt("enter_y", 1200));
        page.addView(followX); page.addView(followY);
        page.addView(commentX); page.addView(commentY);
        page.addView(okX); page.addView(okY);
        page.addView(searchX); page.addView(searchY);
        page.addView(enterX); page.addView(enterY);
        page.addView(button("Enregistrer les positions", v -> {
            prefs.edit().putInt("follow_x", positive(followX, 0)).putInt("follow_y", positive(followY, 0))
                    .putInt("comment_x", positive(commentX, 949)).putInt("comment_y", positive(commentY, 2179))
                    .putInt("ok_x", positive(okX, 0)).putInt("ok_y", positive(okY, 0))
                    .putInt("search_x", positive(searchX, 674)).putInt("search_y", positive(searchY, 100))
                    .putInt("enter_x", positive(enterX, 540)).putInt("enter_y", positive(enterY, 1200)).apply();
            toast("Positions enregistrées");
        }));
        addBackButton(page);
        setContentView(scroll(page));
    }

    private void showAccounts() {
        LinearLayout page = base(editingUser == null ? "Comptes" : "Modifier un compte");
        page.addView(section(editingUser == null ? "Ajouter un compte" : "Modifier le compte sélectionné"));

        String oldRecord = findAccount(editingUser);
        String[] old = oldRecord == null ? new String[0] : oldRecord.split("\\|", -1);
        EditText username = field("Nom du compte TikTok", old.length > 0 ? old[0] : "");
        EditText packageName = field("Package de l’application", old.length > 1 ? old[1] : "");
        CheckBox skipLike = check("Ignorer Like", old.length > 2 && "1".equals(old[2]));
        CheckBox skipFollow = check("Ignorer Follow", old.length > 3 && "1".equals(old[3]));
        CheckBox skipComment = check("Ignorer Commentaire", old.length > 4 && "1".equals(old[4]));
        page.addView(username); page.addView(packageName);
        page.addView(skipLike); page.addView(skipFollow); page.addView(skipComment);
        page.addView(button(editingUser == null ? "Ajouter le compte" : "Enregistrer la modification", v -> {
            String user = username.getText().toString().trim();
            String pkg = packageName.getText().toString().trim();
            if (user.isEmpty() || pkg.isEmpty()) {
                toast("Renseigne le nom et le package");
                return;
            }
            Set<String> accounts = new LinkedHashSet<>(prefs.getStringSet("accounts", new LinkedHashSet<>()));
            if (editingUser != null) {
                String previous = findAccount(editingUser);
                if (previous != null) accounts.remove(previous);
            }
            String record = user + "|" + pkg + "|" + (skipLike.isChecked() ? "1" : "0") + "|" + (skipFollow.isChecked() ? "1" : "0") + "|" + (skipComment.isChecked() ? "1" : "0");
            String previousSameUser = findAccount(user);
            if (previousSameUser != null) accounts.remove(previousSameUser);
            accounts.add(record);
            prefs.edit().putStringSet("accounts", accounts).apply();
            editingUser = null;
            toast("Compte enregistré dans l’application");
            showAccounts();
        }));
        if (editingUser != null) {
            page.addView(button("Annuler la modification", v -> { editingUser = null; showAccounts(); }));
        }

        page.addView(section("Comptes enregistrés"));
        List<String> accounts = new ArrayList<>(prefs.getStringSet("accounts", new LinkedHashSet<>()));
        if (accounts.isEmpty()) {
            page.addView(label("Aucun compte enregistré."));
        } else {
            for (String record : accounts) {
                String[] parts = record.split("\\|", -1);
                String user = parts.length > 0 ? parts[0] : record;
                String pkg = parts.length > 1 ? parts[1] : "";
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(0, dp(8), 0, dp(8));
                row.addView(label(user + "  →  " + pkg));
                LinearLayout actions = new LinearLayout(this);
                actions.addView(button("Modifier", v -> { editingUser = user; showAccounts(); }));
                actions.addView(button("Supprimer", v -> {
                    Set<String> updated = new LinkedHashSet<>(prefs.getStringSet("accounts", new LinkedHashSet<>()));
                    updated.remove(record);
                    prefs.edit().putStringSet("accounts", updated).apply();
                    showAccounts();
                }));
                row.addView(actions);
                page.addView(row);
            }
        }
        addBackButton(page);
        setContentView(scroll(page));
    }

    private String findAccount(String username) {
        if (username == null) return null;
        for (String record : prefs.getStringSet("accounts", new LinkedHashSet<>())) {
            String[] parts = record.split("\\|", -1);
            if (parts.length > 0 && username.equals(parts[0])) return record;
        }
        return null;
    }

    private CheckBox check(String text, boolean checked) {
        CheckBox box = new CheckBox(this);
        box.setText(text);
        box.setChecked(checked);
        box.setTextColor(0xFFFFFFFF);
        return box;
    }

    private void showOpenLink() {
        LinearLayout page = base("Ouvrir un lien");
        page.addView(section("Ouverture Android native"));
        EditText link = field("https://...", prefs.getString("search_url", ""));
        page.addView(link);
        page.addView(button("Ouvrir dans le navigateur", v -> {
            String value = link.getText().toString().trim();
            if (value.isEmpty()) {
                toast("Entre un lien");
                return;
            }
            if (!value.startsWith("http://") && !value.startsWith("https://")) value = "https://" + value;
            prefs.edit().putString("search_url", value).apply();
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(value)));
            } catch (Exception e) {
                toast("Aucune application ne peut ouvrir ce lien");
            }
        }));
        addBackButton(page);
        setContentView(scroll(page));
    }

    private void showAbout() {
        LinearLayout page = base("À propos et limites");
        page.addView(label("Cette version remplace les réglages texte par des menus Android et une sauvegarde locale. Elle ne contient pas encore l’automatisation d’une autre application. Les fonctions liées à ADB, uiautomator2, CAPTCHA ou au contournement des protections ne sont pas intégrées dans l’APK."));
        addBackButton(page);
        setContentView(scroll(page));
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
