package com.example.watchtest;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.LinkedHashSet;
import java.util.Set;

public class MainActivity extends AppCompatActivity {
    private static final String PREFS = "app_settings";
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        showHome();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView title(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(24);
        view.setTextColor(0xFFFFFFFF);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(12), dp(18), dp(12), dp(18));
        return view;
    }

    private TextView section(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(18);
        view.setTextColor(0xFF80CBC4);
        view.setPadding(0, dp(16), 0, dp(8));
        return view;
    }

    private EditText field(String hint, String value) {
        EditText edit = new EditText(this);
        edit.setHint(hint);
        edit.setText(value == null ? "" : value);
        edit.setTextColor(0xFFFFFFFF);
        edit.setHintTextColor(0xFF9E9E9E);
        edit.setPadding(dp(12), dp(8), dp(12), dp(8));
        return edit;
    }

    private Button button(String text, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(text);
        button.setOnClickListener(listener);
        return button;
    }

    private LinearLayout base(String heading) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(10), dp(18), dp(18));
        root.setBackgroundColor(0xFF101820);
        root.addView(title(heading));
        return root;
    }

    private ScrollView scroll(LinearLayout content) {
        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);
        return scroll;
    }

    private void showHome() {
        LinearLayout page = base("TikTok Tools – Android");
        page.addView(section("Prototype Android"));
        TextView info = new TextView(this);
        info.setText("Les réglages sont enregistrés directement dans l’application. Aucun fichier apk.txt ou time.txt n’est nécessaire.");
        info.setTextColor(0xFFE0E0E0);
        info.setTextSize(16);
        page.addView(info);
        page.addView(button("Comptes", v -> showAccounts()));
        page.addView(button("Paramètres", v -> showSettings()));
        page.addView(button("Délais et répétitions", v -> showDelays()));
        page.addView(button("Positions et zones", v -> showPositions()));
        page.addView(button("Ouvrir un lien", v -> showOpenLink()));
        page.addView(button("À propos", v -> showAbout()));
        setContentView(scroll(page));
    }

    private void addBackButton(LinearLayout page) {
        page.addView(button("← Retour à l’accueil", v -> showHome()));
    }

    private void showSettings() {
        LinearLayout page = base("Paramètres");
        page.addView(section("Configuration générale"));
        EditText server = field("URL du serveur", prefs.getString("server_url", "http://localhost:8000"));
        EditText search = field("Lien de recherche ou vidéo", prefs.getString("search_url", ""));
        EditText bot = field("Nom du bot Telegram", prefs.getString("bot_name", ""));
        page.addView(server);
        page.addView(search);
        page.addView(bot);
        page.addView(button("Enregistrer les paramètres", v -> {
            prefs.edit().putString("server_url", server.getText().toString().trim())
                    .putString("search_url", search.getText().toString().trim())
                    .putString("bot_name", bot.getText().toString().trim()).apply();
            toast("Paramètres enregistrés dans l’application");
        }));
        addBackButton(page);
        setContentView(scroll(page));
    }

    private void showDelays() {
        LinearLayout page = base("Délais et répétitions");
        page.addView(section("Valeurs en secondes"));
        EditText response = numberField("Délai de réponse", prefs.getInt("response_delay", 2));
        EditText task = numberField("Délai entre les tâches", prefs.getInt("task_delay", 0));
        EditText follow = numberField("Délai après Follow", prefs.getInt("follow_delay", 5));
        EditText repeat = numberField("Répétitions par compte", prefs.getInt("repeat_count", 1));
        page.addView(response);
        page.addView(task);
        page.addView(follow);
        page.addView(repeat);
        page.addView(button("Enregistrer les délais", v -> {
            prefs.edit().putInt("response_delay", positive(response, 2))
                    .putInt("task_delay", positive(task, 0))
                    .putInt("follow_delay", positive(follow, 5))
                    .putInt("repeat_count", positive(repeat, 1)).apply();
            toast("Délais enregistrés");
        }));
        addBackButton(page);
        setContentView(scroll(page));
    }

    private EditText numberField(String hint, int value) {
        EditText edit = field(hint, String.valueOf(value));
        edit.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return edit;
    }

    private int positive(EditText edit, int fallback) {
        try {
            int value = Integer.parseInt(edit.getText().toString().trim());
            return value >= 0 ? value : fallback;
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private void showPositions() {
        LinearLayout page = base("Positions et zones");
        page.addView(section("Coordonnées tactiles"));
        EditText followX = numberField("Follow – X", prefs.getInt("follow_x", 0));
        EditText followY = numberField("Follow – Y", prefs.getInt("follow_y", 0));
        EditText commentX = numberField("Publier commentaire – X", prefs.getInt("comment_x", 949));
        EditText commentY = numberField("Publier commentaire – Y", prefs.getInt("comment_y", 2179));
        EditText okX = numberField("OK – X", prefs.getInt("ok_x", 0));
        EditText okY = numberField("OK – Y", prefs.getInt("ok_y", 0));
        page.addView(followX); page.addView(followY);
        page.addView(commentX); page.addView(commentY);
        page.addView(okX); page.addView(okY);
        page.addView(button("Enregistrer les positions", v -> {
            prefs.edit().putInt("follow_x", positive(followX, 0)).putInt("follow_y", positive(followY, 0))
                    .putInt("comment_x", positive(commentX, 949)).putInt("comment_y", positive(commentY, 2179))
                    .putInt("ok_x", positive(okX, 0)).putInt("ok_y", positive(okY, 0)).apply();
            toast("Positions enregistrées");
        }));
        addBackButton(page);
        setContentView(scroll(page));
    }

    private void showAccounts() {
        LinearLayout page = base("Comptes");
        page.addView(section("Ajouter ou modifier un compte"));
        EditText username = field("Nom du compte TikTok", "");
        EditText packageName = field("Package de l’application", "");
        CheckBox skipLike = check("Ignorer Like");
        CheckBox skipFollow = check("Ignorer Follow");
        CheckBox skipComment = check("Ignorer Commentaire");
        page.addView(username); page.addView(packageName);
        page.addView(skipLike); page.addView(skipFollow); page.addView(skipComment);
        page.addView(button("Ajouter le compte", v -> {
            String user = username.getText().toString().trim();
            String pkg = packageName.getText().toString().trim();
            if (user.isEmpty() || pkg.isEmpty()) {
                toast("Renseigne le nom et le package");
                return;
            }
            Set<String> accounts = new LinkedHashSet<>(prefs.getStringSet("accounts", new LinkedHashSet<>()));
            String record = user + "|" + pkg + "|" + (skipLike.isChecked() ? "1" : "0") + "|" + (skipFollow.isChecked() ? "1" : "0") + "|" + (skipComment.isChecked() ? "1" : "0");
            accounts.removeIf(item -> item.startsWith(user + "|"));
            accounts.add(record);
            prefs.edit().putStringSet("accounts", accounts).apply();
            toast("Compte enregistré dans l’application");
            showAccounts();
        }));
        page.addView(section("Comptes enregistrés"));
        Set<String> accounts = prefs.getStringSet("accounts", new LinkedHashSet<>());
        if (accounts.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("Aucun compte enregistré.");
            empty.setTextColor(0xFFE0E0E0);
            page.addView(empty);
        } else {
            for (String record : accounts) {
                String[] parts = record.split("\\|", -1);
                String label = parts.length >= 2 ? parts[0] + " → " + parts[1] : record;
                page.addView(button("Supprimer : " + label, v -> {
                    Set<String> updated = new LinkedHashSet<>(prefs.getStringSet("accounts", new LinkedHashSet<>()));
                    updated.remove(record);
                    prefs.edit().putStringSet("accounts", updated).apply();
                    showAccounts();
                }));
            }
        }
        addBackButton(page);
        setContentView(scroll(page));
    }

    private CheckBox check(String text) {
        CheckBox box = new CheckBox(this);
        box.setText(text);
        box.setTextColor(0xFFFFFFFF);
        return box;
    }

    private void showOpenLink() {
        LinearLayout page = base("Ouvrir un lien");
        page.addView(section("Ouverture Android native"));
        EditText link = field("https://...", prefs.getString("search_url", ""));
        page.addView(link);
        page.addView(button("Ouvrir dans le navigateur", v -> {
            String value = link.getText().toString().trim();
            if (value.isEmpty()) {
                toast("Entre un lien");
                return;
            }
            if (!value.startsWith("http://") && !value.startsWith("https://")) value = "https://" + value;
            prefs.edit().putString("search_url", value).apply();
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(value)));
            } catch (Exception e) {
                toast("Aucune application ne peut ouvrir ce lien");
            }
        }));
        addBackButton(page);
        setContentView(scroll(page));
    }

    private void showAbout() {
        LinearLayout page = base("À propos");
        TextView about = new TextView(this);
        about.setText("Prototype Android de conversion de b.py\n\nLes fichiers de réglages sont remplacés par des menus et une sauvegarde locale. Les fonctions d’automatisation externe seront ajoutées séparément avec les permissions Android nécessaires.");
        about.setTextColor(0xFFE0E0E0);
        about.setTextSize(16);
        page.addView(about);
        addBackButton(page);
        setContentView(scroll(page));
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
