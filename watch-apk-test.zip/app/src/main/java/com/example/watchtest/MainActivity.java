package com.example.watchtest;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    private static final String PREFS = "app_settings";
    private static final String TASKS_KEY = "telegram_tasks";
    private static final String CHANNEL_ID = "telegram_tasks";
    private final ExecutorService network = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private String editingUser = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        showHome();
    }

    @Override
    protected void onDestroy() {
        network.shutdownNow();
        super.onDestroy();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView title(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(24);
        view.setTextColor(0xFFFFFFFF);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(12), dp(18), dp(12), dp(18));
        return view;
    }

    private TextView section(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(18);
        view.setTextColor(0xFF80CBC4);
        view.setPadding(0, dp(16), 0, dp(8));
        return view;
    }

    private TextView label(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(0xFFE0E0E0);
        view.setTextSize(15);
        view.setPadding(0, dp(8), 0, dp(2));
        return view;
    }

    private EditText field(String hint, String value) {
        EditText edit = new EditText(this);
        edit.setHint(hint);
        edit.setText(value == null ? "" : value);
        edit.setTextColor(0xFFFFFFFF);
        edit.setHintTextColor(0xFF9E9E9E);
        edit.setPadding(dp(12), dp(8), dp(12), dp(8));
        return edit;
    }

    private Button button(String text, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(text);
        button.setOnClickListener(listener);
        return button;
    }

    private LinearLayout base(String heading) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(10), dp(18), dp(18));
        root.setBackgroundColor(0xFF101820);
        root.addView(title(heading));
        return root;
    }

    private ScrollView scroll(LinearLayout content) {
        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);
        return scroll;
    }

    private void showHome() {
        LinearLayout page = base("TikTok Tools – Android");
        page.addView(section("Version avec tâches Telegram et confirmation humaine"));
        page.addView(label("Les réglages et les tâches sont enregistrés dans l’application. ADB, uiautomator2 et résolution automatique des CAPTCHA ne sont pas utilisés."));
        page.addView(button("Telegram et tâches", v -> showTelegram()));
        page.addView(button("Accessibilité Android", v -> showAccessibility()));
        page.addView(button("Comptes", v -> showAccounts()));
        page.addView(button("Paramètres généraux", v -> showSettings()));
        page.addView(button("Délais et répétitions", v -> showDelays()));
        page.addView(button("Positions et zones", v -> showPositions()));
        page.addView(button("Ouvrir un lien", v -> showOpenLink()));
        page.addView(button("Historique des tâches", v -> showTaskHistory()));
        page.addView(button("À propos et limites", v -> showAbout()));
        setContentView(scroll(page));
    }

    private void addBackButton(LinearLayout page) {
        page.addView(button("← Retour à l’accueil", v -> showHome()));
    }

    private void showTelegram() {
        LinearLayout page = base("Telegram et tâches");
        page.addView(section("Connexion au Bot API Telegram"));
        page.addView(label("Utilise un bot Telegram dédié. Le token est conservé localement sur le téléphone et ne doit pas être partagé."));
        EditText token = field("Token du bot Telegram", prefs.getString("telegram_bot_token", ""));
        token.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        EditText chat = field("ID du chat autorisé (facultatif)", prefs.getString("telegram_chat_id", ""));
        page.addView(token);
        page.addView(chat);
        page.addView(button("Enregistrer Telegram", v -> {
            prefs.edit().putString("telegram_bot_token", token.getText().toString().trim())
                    .putString("telegram_chat_id", chat.getText().toString().trim()).apply();
            toast("Configuration Telegram enregistrée");
        }));
        page.addView(button("Récupérer les nouvelles tâches", v -> {
            prefs.edit().putString("telegram_bot_token", token.getText().toString().trim())
                    .putString("telegram_chat_id", chat.getText().toString().trim()).apply();
            pollTelegram();
        }));
        page.addView(button("Réinitialiser la position Telegram", v -> {
            prefs.edit().putInt("telegram_offset", 0).apply();
            toast("Position réinitialisée");
        }));
        page.addView(section("File d’attente locale"));
        page.addView(label("Les messages contenant un lien TikTok deviennent des tâches. Tu ouvres ensuite le lien et confirmes manuellement l’action."));
        page.addView(button("Voir les tâches en attente", v -> showTaskHistory()));
        addBackButton(page);
        setContentView(scroll(page));
    }

    private void pollTelegram() {
        final String token = prefs.getString("telegram_bot_token", "").trim();
        if (token.isEmpty()) {
            toast("Ajoute d’abord le token du bot Telegram");
            return;
        }
        toast("Récupération des messages Telegram...");
        network.execute(() -> {
            int added = 0;
            int nextOffset = prefs.getInt("telegram_offset", 0);
            try {
                String endpoint = "https://api.telegram.org/bot" + token + "/getUpdates?timeout=0&offset=" + nextOffset;
                HttpURLConnection connection = (HttpURLConnection) new URL(endpoint).openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(15000);
                int code = connection.getResponseCode();
                InputStream stream = code >= 400 ? connection.getErrorStream() : connection.getInputStream();
                String body = readAll(stream);
                JSONObject root = new JSONObject(body);
                if (!root.optBoolean("ok", false)) throw new Exception(root.optString("description", "Réponse Telegram invalide"));
                JSONArray results = root.optJSONArray("result");
                if (results != null) {
                    for (int i = 0; i < results.length(); i++) {
                        JSONObject update = results.getJSONObject(i);
                        int updateId = update.optInt("update_id", nextOffset);
                        nextOffset = Math.max(nextOffset, updateId + 1);
                        JSONObject message = update.optJSONObject("message");
                        if (message == null) continue;
                        String chatId = message.optJSONObject("chat") == null ? "" : message.optJSONObject("chat").optString("id", "");
                        String allowedChat = prefs.getString("telegram_chat_id", "").trim();
                        if (!allowedChat.isEmpty() && !allowedChat.equals(chatId)) continue;
                        String text = message.optString("text", "").trim();
                        String videoUrl = extractTikTokUrl(text);
                        if (!text.isEmpty() && videoUrl != null) {
                            addTask(String.valueOf(updateId), actionFromText(text), videoUrl, text);
                            added++;
                        }
                    }
                }
                prefs.edit().putInt("telegram_offset", nextOffset).apply();
                int finalAdded = added;
                runOnUiThread(() -> {
                    if (finalAdded > 0) notifyTask(finalAdded);
                    toast(finalAdded + " nouvelle(s) tâche(s) reçue(s)");
                    showTaskHistory();
                });
            } catch (Exception error) {
                runOnUiThread(() -> toast("Erreur Telegram : " + error.getMessage()));
            }
        });
    }

    private String readAll(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder result = new StringBuilder();
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        String line;
        while ((line = reader.readLine()) != null) result.append(line);
        reader.close();
        return result.toString();
    }

    private String extractTikTokUrl(String text) {
        Matcher matcher = Pattern.compile("https?://(?:www\\.)?(?:vm\\.)?tiktok\\.com/[^\\s]+", Pattern.CASE_INSENSITIVE).matcher(text);
        if (!matcher.find()) return null;
        return matcher.group().replaceAll("[),.\\]}>]+$", "");
    }

    private String actionFromText(String text) {
        String lower = text.toLowerCase();
        if (lower.contains("comment") || lower.contains("commentaire")) return "commentaire";
        if (lower.contains("follow") || lower.contains("abonn")) return "abonnement";
        if (lower.contains("like") || lower.contains("j'aime") || lower.contains("jaime")) return "like";
        return "à vérifier";
    }

    private synchronized void addTask(String id, String action, String url, String text) throws Exception {
        JSONArray tasks = getTasks();
        for (int i = 0; i < tasks.length(); i++) {
            if (id.equals(tasks.getJSONObject(i).optString("id"))) return;
        }
        JSONObject task = new JSONObject();
        task.put("id", id);
        task.put("action", action);
        task.put("url", url);
        task.put("text", text);
        task.put("status", "En attente");
        task.put("created", DateFormat.getDateTimeInstance().format(new Date()));
        tasks.put(task);
        prefs.edit().putString(TASKS_KEY, tasks.toString()).apply();
    }

    private JSONArray getTasks() {
        try {
            return new JSONArray(prefs.getString(TASKS_KEY, "[]"));
        } catch (Exception ignored) {
            return new JSONArray();
        }
    }

    private void showTaskHistory() {
        LinearLayout page = base("Tâches Telegram");
        JSONArray tasks = getTasks();
        if (tasks.length() == 0) {
            page.addView(label("Aucune tâche reçue. Configure Telegram puis appuie sur Récupérer les nouvelles tâches."));
        } else {
            for (int i = tasks.length() - 1; i >= 0; i--) {
                try {
                    JSONObject task = tasks.getJSONObject(i);
                    final String id = task.optString("id");
                    final String url = task.optString("url");
                    final String action = task.optString("action", "à vérifier");
                    final String text = task.optString("text", "");
                    final String status = task.optString("status", "En attente");
                    LinearLayout row = new LinearLayout(this);
                    row.setOrientation(LinearLayout.VERTICAL);
                    row.setPadding(0, dp(10), 0, dp(10));
                    row.addView(section(action + " – " + status));
                    row.addView(label(url));
                    row.addView(label(text));
                    row.addView(label("Reçu : " + task.optString("created", "")));
                    LinearLayout actions = new LinearLayout(this);
                    if ("En attente".equals(status)) {
                        actions.addView(button("Ouvrir le lien", v -> openUrl(url)));
                        if ("commentaire".equals(action)) actions.addView(button("Copier le texte", v -> copyText(text)));
                        actions.addView(button("Terminé", v -> updateTaskStatus(id, "Terminé")));
                        actions.addView(button("Ignorer", v -> updateTaskStatus(id, "Ignoré")));
                    }
                    row.addView(actions);
                    page.addView(row);
                } catch (Exception ignored) { }
            }
            page.addView(button("Effacer l’historique", v -> {
                prefs.edit().remove(TASKS_KEY).apply();
                showTaskHistory();
            }));
        }
        addBackButton(page);
        setContentView(scroll(page));
    }

    private void updateTaskStatus(String id, String status) {
        JSONArray tasks = getTasks();
        try {
            for (int i = 0; i < tasks.length(); i++) {
                JSONObject task = tasks.getJSONObject(i);
                if (id.equals(task.optString("id"))) task.put("status", status);
            }
            prefs.edit().putString(TASKS_KEY, tasks.toString()).apply();
            toast("Tâche marquée : " + status);
            showTaskHistory();
        } catch (Exception error) {
            toast("Impossible de mettre à jour la tâche");
        }
    }

    private void openUrl(String value) {
        if (value == null || value.trim().isEmpty()) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(value)));
        } catch (Exception error) {
            toast("Aucune application ne peut ouvrir ce lien");
        }
    }

    private void copyText(String text) {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Commentaire", text));
        toast("Texte copié. Colle-le manuellement dans l’application cible.");
    }

    private void notifyTask(int count) {
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(new NotificationChannel(CHANNEL_ID, "Tâches Telegram", NotificationManager.IMPORTANCE_DEFAULT));
        }
        Intent intent = new Intent(this, MainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pending = PendingIntent.getActivity(this, 10, intent, flags);
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Nouvelle tâche Telegram")
                .setContentText(count + " tâche(s) attendent une confirmation")
                .setAutoCancel(true)
                .setContentIntent(pending);
        manager.notify(1001, builder.build());
    }

    private void showSettings() {
        LinearLayout page = base("Paramètres généraux");
        page.addView(section("Services et identifiants d’action"));
        EditText server = field("URL du serveur", prefs.getString("server_url", "http://localhost:8000"));
        EditText search = field("Lien de recherche ou vidéo", prefs.getString("search_url", ""));
        EditText bot = field("Nom du bot Telegram", prefs.getString("bot_name", ""));
        EditText likeId = field("Resource ID Like", prefs.getString("like_resource_id", "ejl"));
        EditText commentId = field("Resource ID Commentaire", prefs.getString("comment_resource_id", "eec"));
        EditText followId = field("Resource ID Follow", prefs.getString("follow_resource_id", ""));
        page.addView(server); page.addView(search); page.addView(bot); page.addView(likeId); page.addView(commentId); page.addView(followId);
        page.addView(button("Enregistrer les paramètres", v -> {
            prefs.edit().putString("server_url", server.getText().toString().trim()).putString("search_url", search.getText().toString().trim()).putString("bot_name", bot.getText().toString().trim()).putString("like_resource_id", likeId.getText().toString().trim()).putString("comment_resource_id", commentId.getText().toString().trim()).putString("follow_resource_id", followId.getText().toString().trim()).apply();
            toast("Paramètres enregistrés dans l’application");
        }));
        addBackButton(page); setContentView(scroll(page));
    }

    private void showDelays() {
        LinearLayout page = base("Délais et répétitions");
        page.addView(section("Valeurs en secondes"));
        EditText response = numberField("Délai de réponse", prefs.getInt("response_delay", 2));
        EditText task = numberField("Délai entre les tâches", prefs.getInt("task_delay", 0));
        EditText follow = numberField("Délai après Follow", prefs.getInt("follow_delay", 5));
        EditText repeat = numberField("Répétitions par compte", prefs.getInt("repeat_count", 1));
        EditText typing = field("Vitesse de saisie, en secondes", prefs.getString("typing_speed", "0.035"));
        typing.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        page.addView(response); page.addView(task); page.addView(follow); page.addView(repeat); page.addView(typing);
        page.addView(button("Enregistrer les délais", v -> {
            prefs.edit().putInt("response_delay", positive(response, 2)).putInt("task_delay", positive(task, 0)).putInt("follow_delay", positive(follow, 5)).putInt("repeat_count", positive(repeat, 1)).putString("typing_speed", typing.getText().toString().trim()).apply();
            toast("Délais enregistrés");
        }));
        addBackButton(page); setContentView(scroll(page));
    }

    private EditText numberField(String hint, int value) {
        EditText edit = field(hint, String.valueOf(value));
        edit.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return edit;
    }

    private int positive(EditText edit, int fallback) {
        try { int value = Integer.parseInt(edit.getText().toString().trim()); return value >= 0 ? value : fallback; }
        catch (Exception ignored) { return fallback; }
    }

    private void showPositions() {
        LinearLayout page = base("Positions et zones");
        page.addView(section("Coordonnées tactiles et zones"));
        EditText followX = numberField("Follow – X", prefs.getInt("follow_x", 0)); EditText followY = numberField("Follow – Y", prefs.getInt("follow_y", 0));
        EditText commentX = numberField("Publier commentaire – X", prefs.getInt("comment_x", 949)); EditText commentY = numberField("Publier commentaire – Y", prefs.getInt("comment_y", 2179));
        EditText okX = numberField("OK – X", prefs.getInt("ok_x", 0)); EditText okY = numberField("OK – Y", prefs.getInt("ok_y", 0));
        EditText searchX = numberField("Recherche – X", prefs.getInt("search_x", 674)); EditText searchY = numberField("Recherche – Y", prefs.getInt("search_y", 100));
        EditText enterX = numberField("Entrée – X", prefs.getInt("enter_x", 540)); EditText enterY = numberField("Entrée – Y", prefs.getInt("enter_y", 1200));
        page.addView(followX); page.addView(followY); page.addView(commentX); page.addView(commentY); page.addView(okX); page.addView(okY); page.addView(searchX); page.addView(searchY); page.addView(enterX); page.addView(enterY);
        page.addView(button("Enregistrer les positions", v -> {
            prefs.edit().putInt("follow_x", positive(followX, 0)).putInt("follow_y", positive(followY, 0)).putInt("comment_x", positive(commentX, 949)).putInt("comment_y", positive(commentY, 2179)).putInt("ok_x", positive(okX, 0)).putInt("ok_y", positive(okY, 0)).putInt("search_x", positive(searchX, 674)).putInt("search_y", positive(searchY, 100)).putInt("enter_x", positive(enterX, 540)).putInt("enter_y", positive(enterY, 1200)).apply();
            toast("Positions enregistrées");
        }));
        addBackButton(page); setContentView(scroll(page));
    }

    private void showAccounts() {
        LinearLayout page = base(editingUser == null ? "Comptes" : "Modifier un compte");
        page.addView(section(editingUser == null ? "Ajouter un compte" : "Modifier le compte sélectionné"));
        String oldRecord = findAccount(editingUser); String[] old = oldRecord == null ? new String[0] : oldRecord.split("\\|", -1);
        EditText username = field("Nom du compte TikTok", old.length > 0 ? old[0] : ""); EditText packageName = field("Package de l’application", old.length > 1 ? old[1] : "");
        CheckBox skipLike = check("Ignorer Like", old.length > 2 && "1".equals(old[2])); CheckBox skipFollow = check("Ignorer Follow", old.length > 3 && "1".equals(old[3])); CheckBox skipComment = check("Ignorer Commentaire", old.length > 4 && "1".equals(old[4]));
        page.addView(username); page.addView(packageName); page.addView(skipLike); page.addView(skipFollow); page.addView(skipComment);
        page.addView(button(editingUser == null ? "Ajouter le compte" : "Enregistrer la modification", v -> {
            String user = username.getText().toString().trim(); String pkg = packageName.getText().toString().trim();
            if (user.isEmpty() || pkg.isEmpty()) { toast("Renseigne le nom et le package"); return; }
            Set<String> accounts = new LinkedHashSet<>(prefs.getStringSet("accounts", new LinkedHashSet<>()));
            if (editingUser != null) { String previous = findAccount(editingUser); if (previous != null) accounts.remove(previous); }
            String record = user + "|" + pkg + "|" + (skipLike.isChecked() ? "1" : "0") + "|" + (skipFollow.isChecked() ? "1" : "0") + "|" + (skipComment.isChecked() ? "1" : "0");
            String previousSameUser = findAccount(user); if (previousSameUser != null) accounts.remove(previousSameUser);
            accounts.add(record); prefs.edit().putStringSet("accounts", accounts).apply(); editingUser = null; toast("Compte enregistré dans l’application"); showAccounts();
        }));
        if (editingUser != null) page.addView(button("Annuler la modification", v -> { editingUser = null; showAccounts(); }));
        page.addView(section("Comptes enregistrés"));
        List<String> accounts = new ArrayList<>(prefs.getStringSet("accounts", new LinkedHashSet<>()));
        if (accounts.isEmpty()) page.addView(label("Aucun compte enregistré."));
        else for (String record : accounts) {
            String[] parts = record.split("\\|", -1); String user = parts.length > 0 ? parts[0] : record; String pkg = parts.length > 1 ? parts[1] : "";
            LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setPadding(0, dp(8), 0, dp(8)); row.addView(label(user + "  →  " + pkg));
            LinearLayout actions = new LinearLayout(this); actions.addView(button("Modifier", v -> { editingUser = user; showAccounts(); })); actions.addView(button("Supprimer", v -> { Set<String> updated = new LinkedHashSet<>(prefs.getStringSet("accounts", new LinkedHashSet<>())); updated.remove(record); prefs.edit().putStringSet("accounts", updated).apply(); showAccounts(); })); row.addView(actions); page.addView(row);
        }
        addBackButton(page); setContentView(scroll(page));
    }

    private String findAccount(String username) {
        if (username == null) return null;
        for (String record : prefs.getStringSet("accounts", new LinkedHashSet<>())) { String[] parts = record.split("\\|", -1); if (parts.length > 0 && username.equals(parts[0])) return record; }
        return null;
    }

    private CheckBox check(String text, boolean checked) { CheckBox box = new CheckBox(this); box.setText(text); box.setChecked(checked); box.setTextColor(0xFFFFFFFF); return box; }

    private void showOpenLink() {
        LinearLayout page = base("Ouvrir un lien"); page.addView(section("Ouverture Android native")); EditText link = field("https://...", prefs.getString("search_url", "")); page.addView(link);
        page.addView(button("Ouvrir dans le navigateur", v -> { String value = link.getText().toString().trim(); if (value.isEmpty()) { toast("Entre un lien"); return; } if (!value.startsWith("http://") && !value.startsWith("https://")) value = "https://" + value; prefs.edit().putString("search_url", value).apply(); openUrl(value); }));
        addBackButton(page); setContentView(scroll(page));
    }

    private void showAccessibility() {
        LinearLayout page = base("Accessibilité Android");
        page.addView(section("Remplacement de la détection par image"));
        page.addView(label("Le service recherche les textes, descriptions et identifiants accessibles des contrôles visibles. Il ne prend pas de capture d’écran et ne clique pas automatiquement."));
        page.addView(button("Ouvrir les réglages d’accessibilité", v -> {
            try {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            } catch (Exception error) {
                toast("Impossible d’ouvrir les réglages Android");
            }
        }));
        page.addView(button("Actualiser le diagnostic", v -> showAccessibility()));
        page.addView(section("Dernier diagnostic"));
        page.addView(label(TaskAccessibilityService.getLastStatus(prefs)));
        page.addView(label("Après avoir activé le service, ouvre l’application cible puis reviens ici pour consulter le dernier diagnostic. Toute action nécessitant un clic reste soumise à une confirmation humaine."));
        addBackButton(page);
        setContentView(scroll(page));
    }

    private void showAbout() {
        LinearLayout page = base("À propos et limites");
        page.addView(label("Cette version reçoit des tâches Telegram via le Bot API, affiche des notifications, ouvre les liens et demande une confirmation humaine. Elle ne contient pas ADB, uiautomator2, automatisation massive, résolution automatique de CAPTCHA ni contournement de protections."));
        addBackButton(page); setContentView(scroll(page));
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
}
