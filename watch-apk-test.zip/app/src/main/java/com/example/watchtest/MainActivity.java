package com.example.watchtest;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView clockText;
    private TextView dateText;

    private final Runnable clockUpdater = new Runnable() {
        @Override
        public void run() {
            Date now = new Date();
            clockText.setText(new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(now));
            dateText.setText(new SimpleDateFormat("EEEE d MMMM yyyy", Locale.getDefault()).format(now));
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(10, 15, 30));
        getWindow().setNavigationBarColor(Color.rgb(10, 15, 30));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(32, 32, 32, 32);

        GradientDrawable background = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(18, 28, 58), Color.rgb(6, 10, 24)});
        root.setBackground(background);

        TextView title = new TextView(this);
        title.setText("MA MONTRE");
        title.setTextColor(Color.rgb(140, 190, 255));
        title.setTextSize(16);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);

        clockText = new TextView(this);
        clockText.setTextColor(Color.WHITE);
        clockText.setTextSize(52);
        clockText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        clockText.setGravity(Gravity.CENTER);
        clockText.setLetterSpacing(0.05f);

        dateText = new TextView(this);
        dateText.setTextColor(Color.rgb(190, 200, 220));
        dateText.setTextSize(17);
        dateText.setGravity(Gravity.CENTER);

        TextView status = new TextView(this);
        status.setText("Application de test APK");
        status.setTextColor(Color.rgb(120, 145, 180));
        status.setTextSize(14);
        status.setGravity(Gravity.CENTER);

        root.addView(title, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams clockParams = new LinearLayout.LayoutParams(-1, -2);
        clockParams.setMargins(0, 30, 0, 10);
        root.addView(clockText, clockParams);
        root.addView(dateText, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
        statusParams.setMargins(0, 42, 0, 0);
        root.addView(status, statusParams);

        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(clockUpdater);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(clockUpdater);
    }
}
