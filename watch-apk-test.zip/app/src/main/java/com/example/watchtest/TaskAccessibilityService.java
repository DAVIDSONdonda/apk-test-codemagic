package com.example.watchtest;

import android.accessibilityservice.AccessibilityService;
import android.content.SharedPreferences;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class TaskAccessibilityService extends AccessibilityService {
    private static final String PREFS = "app_settings";
    private static final String LAST_CONTROLS = "accessibility_last_controls";
    private static final String LAST_PACKAGE = "accessibility_last_package";
    private static final String LAST_TIME = "accessibility_last_time";
    private static final Set<String> TARGET_WORDS = new HashSet<>();

    static {
        TARGET_WORDS.add("like");
        TARGET_WORDS.add("j'aime");
        TARGET_WORDS.add("jaime");
        TARGET_WORDS.add("follow");
        TARGET_WORDS.add("suivre");
        TARGET_WORDS.add("abonner");
        TARGET_WORDS.add("comment");
        TARGET_WORDS.add("commenter");
        TARGET_WORDS.add("ajouter un commentaire");
        TARGET_WORDS.add("publier");
    }

    public static TaskAccessibilityService instance;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        saveStatus("Service actif", getPackageName());
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        List<String> controls = new ArrayList<>();
        collectTargetControls(root, controls);
        if (!controls.isEmpty()) {
            StringBuilder summary = new StringBuilder();
            for (String control : controls) {
                if (summary.length() > 0) summary.append("\n");
                summary.append(control);
            }
            saveStatus(summary.toString(), event.getPackageName() == null ? "" : event.getPackageName().toString());
        }
        root.recycle();
    }

    private void collectTargetControls(AccessibilityNodeInfo node, List<String> output) {
        if (node == null) return;
        String text = node.getText() == null ? "" : node.getText().toString().trim();
        String description = node.getContentDescription() == null ? "" : node.getContentDescription().toString().trim();
        String viewId = node.getViewIdResourceName() == null ? "" : node.getViewIdResourceName();
        String normalizedViewId = normalizeId(viewId);
        String configuredLike = normalizeId(getSharedPreferences(PREFS, MODE_PRIVATE).getString("like_resource_id", "ejl"));
        String configuredComment = normalizeId(getSharedPreferences(PREFS, MODE_PRIVATE).getString("comment_resource_id", "eec"));
        String configuredFollow = normalizeId(getSharedPreferences(PREFS, MODE_PRIVATE).getString("follow_resource_id", ""));
        if (!normalizedViewId.isEmpty() && (normalizedViewId.equals(configuredLike) || normalizedViewId.equals(configuredComment) || (!configuredFollow.isEmpty() && normalizedViewId.equals(configuredFollow)))) {
            String role = normalizedViewId.equals(configuredLike) ? "Like" : (normalizedViewId.equals(configuredComment) ? "Commentaire" : "Follow");
            String value = text.isEmpty() ? description : text;
            if (value.isEmpty()) value = viewId;
            String line = "[Resource ID " + role + "] " + value + " → " + viewId + (node.isClickable() ? " [cliquable]" : " [accessible]");
            if (!output.contains(line)) output.add(line);
        }
        String combined = (text + " " + description + " " + viewId).toLowerCase(Locale.ROOT);
        for (String word : TARGET_WORDS) {
            if (combined.contains(word)) {
                String value = text.isEmpty() ? description : text;
                if (value.isEmpty()) value = viewId;
                String line = value + (node.isClickable() ? " [cliquable]" : " [accessible]");
                if (!output.contains(line)) output.add(line);
                break;
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) collectTargetControls(node.getChild(i), output);
    }

    private String normalizeId(String value) {
        if (value == null) return "";
        String normalized = value.trim().toLowerCase(Locale.ROOT);
        int slash = normalized.lastIndexOf('/');
        int colon = normalized.lastIndexOf(':');
        int cut = Math.max(slash, colon);
        return cut >= 0 ? normalized.substring(cut + 1) : normalized;
    }

    private void saveStatus(String controls, String packageName) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(LAST_CONTROLS, controls)
                .putString(LAST_PACKAGE, packageName)
                .putLong(LAST_TIME, System.currentTimeMillis())
                .apply();
    }

    public static String getLastStatus(SharedPreferences prefs) {
        String controls = prefs.getString(LAST_CONTROLS, "Service inactif ou aucun contrôle correspondant trouvé.");
        String packageName = prefs.getString(LAST_PACKAGE, "");
        return packageName.isEmpty() ? controls : "Application : " + packageName + "\n" + controls;
    }

    @Override
    public void onInterrupt() {
        saveStatus("Service interrompu", "");
    }

    @Override
    public void onDestroy() {
        instance = null;
        saveStatus("Service arrêté", "");
        super.onDestroy();
    }
}
