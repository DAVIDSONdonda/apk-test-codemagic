# Règles ProGuard supplémentaires pour l’application de test.
